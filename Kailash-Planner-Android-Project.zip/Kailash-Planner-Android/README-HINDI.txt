KAILASH PLANNER - ANDROID APK PROJECT

Yeh Android Studio project hai. Is ZIP ke andar app ka offline HTML version Android app ke andar bundle hai.

APK banane ka aasaan tareeka (PC/laptop chahiye):
1. Android Studio install karein: https://developer.android.com/studio
2. Is ZIP ko extract karein.
3. Android Studio me extracted Kailash-Planner-Android folder open karein.
4. Gradle sync complete hone dein.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) par click karein.
6. APK app/build/outputs/apk/debug/app-debug.apk me milega.

Agar PC nahi hai: GitHub account par is project ko repository me upload karein. GitHub ke Actions tab me “Build Kailash Planner APK” workflow run karein. Run complete hone par “Kailash-Planner-APK” artifact download karein; us ZIP ke andar app-debug.apk hoga.

NOTE:
- Yeh project source hai, pehle se compiled APK nahi.
- App offline chalti hai aur task data isi app/device ke local storage me rehta hai.
- Is version me Android notification reminders nahi hain.
